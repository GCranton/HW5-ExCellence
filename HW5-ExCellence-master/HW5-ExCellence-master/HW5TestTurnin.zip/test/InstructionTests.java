/**
 * Test class for instructions.
 */
public class InstructionTests {

}
